**Test Plan Medbots**


**1 Testing Strategy**

**1.1 Overall strategy** 

----------



**1.2 Test Selection**


----------
 


**1.3 Adequacy Criterion** 

----------




**1.4 Bug Tracking** 

----------


**1.5 Technology** 

----------


# **2 Test Cases:**

----------

