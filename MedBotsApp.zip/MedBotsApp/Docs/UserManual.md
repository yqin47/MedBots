# Medbots
# User Manual

### Table of Contents  

1. Introduction/Overview  
2. Starting the application  



### 1. Introduction/Overview

### 2. Starting the application
